# GPS Tracker Realtime

MQTT → Kafka → PostGIS + Redis → WebSocket Dashboard
