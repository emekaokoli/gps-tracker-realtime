// WebSocket server: broadcasts Redis GPS updates to dashboard clients
