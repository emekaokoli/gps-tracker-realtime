// Offline checker: marks drivers offline if no updates in X seconds
