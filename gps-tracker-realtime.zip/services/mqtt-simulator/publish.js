// MQTT publisher: simulates GPS updates from drivers
