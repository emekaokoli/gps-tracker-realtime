// Kafka consumer: stores GPS data to PostGIS and broadcasts to Redis
